package com.demo.spring.integration.file;

import java.io.IOException;

import org.springframework.context.support.ClassPathXmlApplicationContext;



public class FileCopyDemo {

    public static void main(String[] args) throws InterruptedException, IOException {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "fileCopyDemoApplicationContext.xml");
        try {            
              Thread.sleep(2000);
        } finally {
            context.close();
        }
    }
    
}
