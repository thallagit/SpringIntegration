package com.demo.spring.integration.file;

import java.io.File;

public class FHandler {
    public File handleFile(File input) {
        System.out.println("Procesing file: " + input.getAbsolutePath());
        return input;
    }
}
