package com.demo.spring.integration.file;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.messaging.MessageHandlingException;

public class ErrorHandler implements ApplicationEventPublisherAware{

  public void myHandler(Exception e) {
    if (e instanceof MessageHandlingException) {
      MessageHandlingException mhe = (MessageHandlingException)e;
      publisher.publishEvent(new ErrorEvent(mhe.getFailedMessage()));
    }
    
}

  private ApplicationEventPublisher publisher;
  
  public void setApplicationEventPublisher(ApplicationEventPublisher publisher) {
      this.publisher = publisher;
  }
}