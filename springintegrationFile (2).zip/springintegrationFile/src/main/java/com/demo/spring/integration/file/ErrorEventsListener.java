package com.demo.spring.integration.file;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.Lifecycle;



public class ErrorEventsListener implements ApplicationListener<ErrorEvent> {
  @Autowired
  Lifecycle filesIn;
  public void onApplicationEvent(ErrorEvent arg0) {
    System.out.println("Received Event");
    filesIn.stop();

  }

}
