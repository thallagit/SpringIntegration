package com.demo.spring.integration.file;

import org.springframework.context.ApplicationEvent;

public class ErrorEvent extends ApplicationEvent {

  public ErrorEvent(Object source) {
    super(source);
    // TODO Auto-generated constructor stub
  }

}
